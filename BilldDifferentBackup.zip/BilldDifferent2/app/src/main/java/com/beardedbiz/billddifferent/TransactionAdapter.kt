package com.beardedbiz.billddifferent

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class TransactionAdapter(private val items: List<Transaction>) :
    RecyclerView.Adapter<TransactionAdapter.TransactionViewHolder>() {

    class TransactionViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val date: TextView = view.findViewById(R.id.transactionDate)
        val source: TextView = view.findViewById(R.id.transactionSource)
        val amount: TextView = view.findViewById(R.id.transactionAmount)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TransactionViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_transaction, parent, false)
        return TransactionViewHolder(view)
    }

    override fun onBindViewHolder(holder: TransactionViewHolder, position: Int) {
        val transaction = items[position]
        holder.date.text = transaction.date
        holder.source.text = transaction.source

        // Format amount (cents to dollars)
        val isNegative = transaction.amount < 0
        val dollars = transaction.amount / 100.0
        val formattedAmount = if (isNegative)
            "($${String.format("%,.2f", -dollars)})"
        else
            "$${String.format("%,.2f", dollars)}"

        holder.amount.text = formattedAmount

        // Color text red for negative, green for positive
        holder.amount.setTextColor(
            if (isNegative) 0xFFC62828.toInt() else 0xFF2E7D32.toInt()
        )

        // Optional: row background tint
        holder.itemView.setBackgroundColor(
            if (isNegative) 0x1AFFCDD2.toInt() else 0x1AC8E6C9.toInt()
        )
    }

    override fun getItemCount(): Int = items.size
}
