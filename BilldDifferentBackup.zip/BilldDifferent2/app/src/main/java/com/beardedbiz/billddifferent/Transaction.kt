package com.beardedbiz.billddifferent

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "transactions")
data class Transaction(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val date: String,
    val source: String,
    val amount: Int  // e.g., -12000 for -$120.00
)

