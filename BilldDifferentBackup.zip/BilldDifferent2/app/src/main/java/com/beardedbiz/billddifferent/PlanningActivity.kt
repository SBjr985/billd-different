package com.beardedbiz.billddifferent

import android.app.DatePickerDialog
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomnavigation.BottomNavigationView
import kotlinx.coroutines.launch

class PlanningActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var dao: TransactionDao

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_planning)

        // 🧠 Set up database
        val db = AppDatabase.getDatabase(this)
        dao = db.transactionDao()

        // 🧭 Bottom navigation setup
        val bottomNav = findViewById<BottomNavigationView>(R.id.bottomNav)
        bottomNav.selectedItemId = R.id.nav_planning
        bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> {
                    startActivity(Intent(this, HomeActivity::class.java))
                    overridePendingTransition(0, 0)
                    true
                }
                R.id.nav_planning -> true
                R.id.nav_reports -> {
                    startActivity(Intent(this, ReportsActivity::class.java))
                    overridePendingTransition(0, 0)
                    true
                }
                else -> false
            }
        }

        // 📄 RecyclerView setup
        recyclerView = findViewById(R.id.planningRecycler)
        recyclerView.layoutManager = LinearLayoutManager(this)

        // 🔄 Load data from DB
        loadTransactions()

        // ➕ Add New Transaction Button
        val addButton = findViewById<Button>(R.id.addNewButton)
        addButton.setOnClickListener { showAddTransactionDialog() }
    }

    private fun loadTransactions() {
        lifecycleScope.launch {
            val transactions = dao.getAll()
            recyclerView.adapter = TransactionAdapter(transactions)
        }
    }

    private fun showAddTransactionDialog() {
        val dialogView = layoutInflater.inflate(R.layout.dialog_add_transaction, null)
        val sourceInput = dialogView.findViewById<EditText>(R.id.inputSource)
        val amountInput = dialogView.findViewById<EditText>(R.id.inputAmount)
        val dateButton = dialogView.findViewById<Button>(R.id.inputDate)
        val recurringCheckbox = dialogView.findViewById<CheckBox>(R.id.recurringCheckbox)
        val recurringOptions = dialogView.findViewById<Spinner>(R.id.recurringOptions)

        var selectedDate = ""

        dateButton.setOnClickListener {
            val picker = DatePickerDialog(this)
            picker.setOnDateSetListener { _, y, m, d ->
                selectedDate = "${m + 1}/$d/$y"
                dateButton.text = selectedDate
            }
            picker.show()
        }

        recurringCheckbox.setOnCheckedChangeListener { _, isChecked ->
            recurringOptions.visibility = if (isChecked) View.VISIBLE else View.GONE
        }

        AlertDialog.Builder(this)
            .setTitle("Add Transaction")
            .setView(dialogView)
            .setPositiveButton("Add") { _, _ ->
                val source = sourceInput.text.toString()
                val amountText = amountInput.text.toString()
                val parsedAmount = try {
                    val clean = amountText.replace("[^\\d.-]".toRegex(), "")
                    (clean.toDouble() * 100).toInt()
                } catch (e: Exception) {
                    null
                }

                if (source.isNotBlank() && parsedAmount != null && selectedDate.isNotBlank()) {
                    lifecycleScope.launch {
                        dao.insert(
                            Transaction(
                                date = selectedDate,
                                source = source,
                                amount = parsedAmount
                            )
                        )
                        loadTransactions()
                    }
                } else {
                    Toast.makeText(this, "Please enter a valid amount and date.", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
