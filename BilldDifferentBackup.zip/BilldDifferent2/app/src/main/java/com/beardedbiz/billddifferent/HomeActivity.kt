package com.beardedbiz.billddifferent

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomnavigation.BottomNavigationView

class HomeActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        val bottomNav = findViewById<BottomNavigationView>(R.id.bottomNav)
        bottomNav.selectedItemId = R.id.nav_home

        bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> true
                R.id.nav_planning -> {
                    startActivity(Intent(this, PlanningActivity::class.java))
                    overridePendingTransition(0, 0)
                    true
                }
                R.id.nav_reports -> {
                    startActivity(Intent(this, ReportsActivity::class.java))
                    overridePendingTransition(0, 0)
                    true
                }
                else -> false
            }
        }

        val transactionList = listOf(
            Transaction(date = "6/10/25", source = "Light Bill", amount = -120),
            Transaction(date = "6/11/25", source = "Gas", amount = -50),
            Transaction(date = "6/12/25", source = "Groceries", amount = -200),
            Transaction(date = "6/13/25", source = "Paycheck", amount = 1000)
        )



        val recyclerView = findViewById<RecyclerView>(R.id.transactionRecycler)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = TransactionAdapter(transactionList)
    }
}
